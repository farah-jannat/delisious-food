import React from 'react'
import Vege from "../components/Vege"
import Popular from "../components/Popular"

function Home() {
  return (
    <div>
        <Vege />
        <Popular />
    </div>
  )
}

export default Home